/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anna
 */
public class testRun {
    public static void main(String[]argv){
    MyComplex z1,z2,w,z;
    z1=new MyComplex(2,30);
    System.out.println("z1.theta="+z1.get_theta());
    z2=new MyComplex(4,120);
    System.out.println("z2.theta="+z2.get_theta());
    w=z1.exponential();
    System.out.print("w=");
    w.print();
    z=z1.product(z2);
    System.out.print("z=");
    z.print();
    }
    
}
