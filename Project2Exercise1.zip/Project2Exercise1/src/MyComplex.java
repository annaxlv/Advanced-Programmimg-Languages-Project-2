/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anna
 */
public class MyComplex {
    private double r,theta;
    public  MyComplex(){
    r=0;
    theta=0;
    }
    
    public MyComplex(double r, double theta){
    this.r=r;
    this.theta=(theta * Math.PI)/180;
    }
    
    public double get_r(){
    return r;
    }
    
    public double get_theta(){
    return theta;
    }
    
    public void print(){
    System.out.println(r*Math.cos(theta)+"+i*("+r*Math.sin(theta)+")");
            }
    
    public MyComplex exponential(){
    MyComplex temp = new MyComplex();
    temp.r=Math.exp(this.r*Math.cos(this.theta));
    temp.theta=this.r*Math.sin(this.theta);
    return temp ;
    }
    
    public MyComplex product(MyComplex x){
    MyComplex temp = new MyComplex();
    temp.r=this.r*x.r;
    temp.theta=this.theta+x.theta;
    return temp;
    }
}
