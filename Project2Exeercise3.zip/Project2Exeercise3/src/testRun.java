/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anna
 */
public class testRun {
    public static void main(String[]args){
    double[] cc = {1,2,3};
    Polynomial p = new Polynomial (cc);
    Polynomial q = (Polynomial) p.integrate();
    Polynomial r = p.addPolynomial(q);
    System.out.println(r.value(4));
    }
    
}
