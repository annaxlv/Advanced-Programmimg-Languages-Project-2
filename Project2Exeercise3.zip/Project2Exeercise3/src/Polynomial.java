/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anna
 */
public class Polynomial extends Function implements Integrable{
    
    protected double[] a;
    
    public Polynomial(double[] coefs){
    a = new double [coefs.length];
    for(int i=0;i<coefs.length;i++){
    a[i]= coefs[i];
    }
    }
    
    public double[] getCoefficients(){
    return a;
}
   
    @Override
    public double value(double x) {
    double sum=0;
    for(int i=0;i<=a.length-1;i++){
    sum=sum + a[i]* Math.pow(x,i);
    }
    return sum;
    }
    
    @Override
    public Function integrate(){
    double[] b = new double[a.length+1];
    b[0]=0;
    for(int i=1;i<b.length;i++){
    b[i]=a[i-1]/i;
    }
    Polynomial q = new Polynomial(b);
    return q;
    }
    
    
    
    public Polynomial addPolynomial(Polynomial p){
    double [] pcoefs = p.getCoefficients();
    double[] qcoefs;
    if(a.length <= pcoefs.length){
    qcoefs = sumofCoefs(a,pcoefs);
    }
    else{
    qcoefs = sumofCoefs(pcoefs,a);
    }
    Polynomial q = new Polynomial(qcoefs);
    return q;
    }
    
    private double [] sumofCoefs(double[] xx,double[] yy){
    double[] c = new double[yy.length];
    for (int i=0;i<xx.length;i++){
    c[i] = xx[i] + yy[i];
    }
    for (int i=xx.length;i<yy.length;i++){
    c[i]=yy[i];
    }
    return c;
    }
    
    
    

  
    
    
   
    } 

    
       
    
    

