/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anna
 */
public class Point3D extends Point {
    double z;
    public Point3D(){
    super(0,0);
    z=0;
}
    
    public Point3D(double x,double y,double z){
    super(x,y);
    this.z=z;
    }
    
    public void move(double x,double y,double z){
    super.move(x, y);
    this.z=z;
    }
    
    public double distance(Point3D p){
    double dx = p.x-x;
    double dy = p.y-y;
    double dz = p.z-z;
    return Math.sqrt(dx*dx +dy*dy + dz*dz);
    }
    
    public static void main(String[]args){
    Point3D p1 = new Point3D(1,2,3);
    Point3D p2 = new Point3D(3,4,5);
    System.out.println(p1.distance(p2));
    }
}
